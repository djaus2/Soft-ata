# Softata-code

## Softata RPi Pico W Sketch

- The RPi Pico W Arduino Sketch
  - Renamed from SoftataOTA
  - Previous Softata sketch deleted.
- Runs Arduino code that supports a TCPIP Service.
- Supports classes for running attached senors, actuators etc that can be orchestrated via the service.
- Also Azure IoT Hub and Bluetooth

> Watch this space